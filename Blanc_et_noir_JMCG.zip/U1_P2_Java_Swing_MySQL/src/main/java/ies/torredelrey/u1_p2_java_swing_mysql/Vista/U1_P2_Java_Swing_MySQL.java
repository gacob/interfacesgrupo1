/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ies.torredelrey.u1_p2_java_swing_mysql.Vista;

/**
 *
 * @author usuario
 */
public class U1_P2_Java_Swing_MySQL {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
