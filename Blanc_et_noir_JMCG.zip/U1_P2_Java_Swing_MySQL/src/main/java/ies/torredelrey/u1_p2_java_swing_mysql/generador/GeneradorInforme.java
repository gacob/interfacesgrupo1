/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ies.torredelrey.u1_p2_java_swing_mysql.generador;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author usuario
 */
public class GeneradorInforme {
    
    
public static void leerInformeBD() {
    try {
        JasperPrint print;
        HashMap param = new HashMap();
        param.put("fecha", "26/01/2025");
        
        String url = "jdbc:mysql://localhost:3306/papeleria";
        String usuario = "root";
        String password = "1234";
        
        Connection conn = DriverManager.getConnection(url, usuario, password);
        
        // Cargar el .jrxml en lugar del .jasper
        InputStream reportStream = GeneradorInforme.class.getResourceAsStream("/reportes/report.jrxml");
        
        if (reportStream == null) {
            System.out.println("ERROR: No se encontró el archivo report3.jrxml");
            return;
        }
        
        // Compilar el reporte en tiempo de ejecución
        JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);
        
        // Llenar el reporte
        print = JasperFillManager.fillReport(jasperReport, param, conn);
        JasperExportManager.exportReportToPdfFile(print, "informePapeleria.pdf");
        
        JasperViewer viewer = new JasperViewer(print, false);
        viewer.setVisible(true);
        
        conn.close();
        
    } catch (JRException ex) {
        Logger.getLogger(GeneradorInforme.class.getName()).log(Level.SEVERE, null, ex);
    } catch (SQLException ex) {
        Logger.getLogger(GeneradorInforme.class.getName()).log(Level.SEVERE, null, ex);
    }
}
    
}
