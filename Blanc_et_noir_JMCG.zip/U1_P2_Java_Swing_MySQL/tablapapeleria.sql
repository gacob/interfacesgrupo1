CREATE TABLE tablapapeleria(
id INTEGER AUTO_INCREMENT PRIMARY KEY,
codigo VARCHAR(45),
producto vARCHAR(50),
familia VARCHAR(50),
precio DOUBLE);
